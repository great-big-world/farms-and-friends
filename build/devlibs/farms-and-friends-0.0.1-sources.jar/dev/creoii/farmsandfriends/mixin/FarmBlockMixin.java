package dev.creoii.farmsandfriends.mixin;

//import dev.creoii.greatbigworld.util.FertilizerUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(FarmBlock.class)
public abstract class FarmBlockMixin extends Block {
    public FarmBlockMixin(Properties properties) {
        super(properties);
    }

    @Inject(method = "fallOn", at = @At("HEAD"), cancellable = true)
    private void gbw$strengthFertilize(Level level, BlockState blockState, BlockPos blockPos, Entity entity, double d, CallbackInfo ci) {
        //if (!level.isClientSide()) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.REPLANT, List.of()).contains(level.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    double chance = Math.pow(j / 4d, 2d);
        //    if (level.random.nextDouble() < chance) {
        //        super.fallOn(level, blockState, blockPos, entity, d);
        //        ci.cancel();
        //    }
        //}
    }
}
