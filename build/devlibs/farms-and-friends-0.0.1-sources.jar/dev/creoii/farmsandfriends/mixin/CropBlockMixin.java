package dev.creoii.farmsandfriends.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsBlocks;
//import dev.creoii.greatbigworld.util.FertilizerUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;

@Mixin(CropBlock.class)
public abstract class CropBlockMixin extends Block {
    @Shadow public abstract int getMaxAge();

    @Shadow
    public abstract BlockState getStateForAge(int i);

    public CropBlockMixin(Properties properties) {
        super(properties);
    }

    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/CropBlock;getGrowthSpeed(Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)F"))
    private float gbw$fertilizeGrowthSpeed(Block block, BlockGetter blockGetter, BlockPos blockPos, Operation<Float> original) {
        float f = original.call(block, blockGetter, blockPos);

        int i = 1;
        //for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //    if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.SPEED, List.of()).contains(blockGetter.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //        f *= 6.25f - i++;
        //    }
        //}

        return f;
    }

    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private boolean gbw$fertilizeOvergrowth(ServerLevel instance, BlockPos blockPos, BlockState blockState, int i, Operation<Boolean> original) {
        //if (i == getMaxAge() && FertilizerUtils.OVERGROWN_CROPS.containsKey(this)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.OVERGROWTH, List.of()).contains(instance.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    if (instance.random.nextDouble() < Math.pow(j / 5d, 2d)) {
        //        BlockState state = FertilizerUtils.OVERGROWN_CROPS.get(this).defaultBlockState();
//
        //        if (state.is(FarmsAndFriendsBlocks.GIANT_POTATO) && instance.random.nextFloat() < .02f)
        //            state = FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO.defaultBlockState();
//
        //        return original.call(instance, blockPos, state, i);
        //    }
        //}
        return original.call(instance, blockPos, blockState, i);
    }

    @WrapOperation(method = "growCrops", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private boolean gbw$fertilizeOvergrowthBonemeal(Level instance, BlockPos blockPos, BlockState blockState, int i, Operation<Boolean> original) {
        //if (i == getMaxAge() && FertilizerUtils.OVERGROWN_CROPS.containsKey(this)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.OVERGROWTH, List.of()).contains(instance.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    if (instance.random.nextDouble() < Math.pow(j / 5d, 2d)) {
        //        BlockState state = FertilizerUtils.OVERGROWN_CROPS.get(this).defaultBlockState();
//
        //        if (state.is(FarmsAndFriendsBlocks.GIANT_POTATO) && instance.random.nextFloat() < .02f)
        //            state = FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO.defaultBlockState();
//
        //        return original.call(instance, blockPos, state, i);
        //    }
        //}
        return original.call(instance, blockPos, blockState, i);
    }

    @Override
    public void playerDestroy(Level level, Player player, BlockPos blockPos, BlockState blockState, @Nullable BlockEntity blockEntity, ItemStack itemStack) {
        //if (canSurvive(blockState, level, blockPos)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.REPLANT, List.of()).contains(level.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    double chance = Math.pow(j / 4d, 2d);
        //    if (level.random.nextDouble() < chance) {
        //        level.setBlock(blockPos, getStateForAge(0), 2);
        //    }
        //}
        super.playerDestroy(level, player, blockPos, blockState, blockEntity, itemStack);
    }
}
