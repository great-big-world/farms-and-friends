package dev.creoii.farmsandfriends.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CactusBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(CactusBlock.class)
public class CactusBlockMixin {
    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextDouble()D"))
    private double gbw$fasterCactusFlowers(RandomSource instance, Operation<Double> original, @Local(argsOnly = true) ServerLevel serverLevel, @Local(argsOnly = true) BlockPos blockPos) {
        double d = original.call(instance);
        BlockPos pos;
        for (int yo = 0; yo < 5; ++yo) {
            pos = blockPos.above(yo);

            if (!serverLevel.getBlockState(pos).canBeReplaced()) return d;
            else if (serverLevel.getBlockState(pos).is(Blocks.OAK_LEAVES)) return 0d;
        }
        return d;
    }
}
