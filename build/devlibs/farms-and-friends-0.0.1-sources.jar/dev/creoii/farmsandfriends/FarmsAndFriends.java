package dev.creoii.farmsandfriends;

import dev.creoii.farmsandfriends.registry.*;
//import dev.creoii.greatbigworld.util.FertilizerUtils;
import net.fabricmc.api.ModInitializer;
import net.minecraft.world.level.block.Blocks;

public class FarmsAndFriends implements ModInitializer {
    @Override
    public void onInitialize() {
        FarmsAndFriendsBlocks.register();
        FarmsAndFriendsBlockEntities.register();
        FarmsAndFriendsItems.register();
        FarmsAndFriendsStatusEffects.register();
        FarmsAndFriendsRecipes.register();
        FarmsAndFriendsScreens.register();
        FarmsAndFriendsStats.register();

        //FertilizerUtils.registerFertilizer(FertilizerUtils.FertilizerType.STABILITY, Blocks.ROOTED_DIRT);
        //FertilizerUtils.registerFertilizer(FertilizerUtils.FertilizerType.REPLANT, Blocks.EMERALD_BLOCK);
        //FertilizerUtils.registerFertilizer(FertilizerUtils.FertilizerType.OVERGROWTH, Blocks.DIAMOND_BLOCK);
        //FertilizerUtils.registerOvergrownCrop(Blocks.CARROTS, FarmsAndFriendsBlocks.GIANT_CARROT);
        //FertilizerUtils.registerOvergrownCrop(Blocks.POTATOES, FarmsAndFriendsBlocks.GIANT_POTATO);
        //FertilizerUtils.registerOvergrownCrop(Blocks.BEETROOTS, FarmsAndFriendsBlocks.GIANT_BEETROOT);
    }
}
