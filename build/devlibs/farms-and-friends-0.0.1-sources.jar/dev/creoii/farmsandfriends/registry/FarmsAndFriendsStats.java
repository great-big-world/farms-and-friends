package dev.creoii.farmsandfriends.registry;

import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

public final class FarmsAndFriendsStats {
    public static Identifier EAT_CHEESE_BITE;

    public static void register() {
        EAT_CHEESE_BITE = Registry.register(BuiltInRegistries.CUSTOM_STAT, Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "eat_cheese_bite"), Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "eat_cheese_bite"));
    }
}
