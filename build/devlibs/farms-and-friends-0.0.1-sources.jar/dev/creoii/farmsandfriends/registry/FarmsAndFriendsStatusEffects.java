package dev.creoii.farmsandfriends.registry;

import net.minecraft.world.effect.MobEffect;

public final class FarmsAndFriendsStatusEffects {
    //public static MobEffect SUGARED; // spring when on low hunger

    public static void register() {

    }
}
