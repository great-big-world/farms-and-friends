package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.block.CheeseWheelBlock;
import dev.creoii.farmsandfriends.block.OvenBlock;
import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class FarmsAndFriendsBlocks {
    //public static Block MORTAR;
    //public static Block TROUGH;
    public static Block OVEN;
    //public static Block WHEATGRASS;
    //public static Block ROTTEN_FLESH_BLOCK;
    public static Block CHEESE_WHEEL;
    public static Block MOLDY_CHEESE_WHEEL;
    //public static Block CHEESECAKE;
    //public static Block CHOCOLATE_CAKE;
    //public static Block CARROT_CAKE;
    //public static Block GOLDEN_APPLE_CAKE;
    //public static Block GOLDEN_CARROT_CAKE;
    //public static Block APPLE_PIE;
    //public static Block BERRY_PIE;
    public static Block MARIGOLD;
    public static Block ROSE;
    public static Block CYAN_ROSE;
    public static Block GIANT_POTATO;
    public static Block GIANT_CARROT;
    public static Block GIANT_BEETROOT;
    public static Block GIANT_POISONOUS_POTATO;
    //public static Block GIANT_NETHER_WART;
    //public static Block GIANT_WHEAT;
    //public static Block GIANT_PUMPKIN; // 2x2 block
    //public static Block GIANT_MELON; // 2x2 block

    public static void register() {
        OVEN = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "oven"), OvenBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.BLAST_FURNACE));

        CHEESE_WHEEL = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "cheese_wheel"), properties -> new CheeseWheelBlock(properties, false), BlockBehaviour.Properties.ofFullCopy(Blocks.CAKE));
        MOLDY_CHEESE_WHEEL = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "moldy_cheese_wheel"), properties -> new CheeseWheelBlock(properties, true), BlockBehaviour.Properties.ofFullCopy(Blocks.CAKE));

        ROSE = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "rose"), properties -> new FlowerBlock(MobEffects.INSTANT_HEALTH, 1, properties), BlockBehaviour.Properties.ofFullCopy(Blocks.POPPY));
        CYAN_ROSE = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "cyan_rose"), properties -> new FlowerBlock(MobEffects.INSTANT_HEALTH, 1, properties), BlockBehaviour.Properties.ofFullCopy(Blocks.LILY_OF_THE_VALLEY));
        MARIGOLD = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "marigold"), properties -> new FlowerBlock(MobEffects.INSTANT_HEALTH, 1, properties), BlockBehaviour.Properties.ofFullCopy(Blocks.DANDELION));

        GIANT_POTATO = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_potato"), BlockBehaviour.Properties.ofFullCopy(Blocks.STONE));
        GIANT_CARROT = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_carrot"), RotatedPillarBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.STONE));
        GIANT_BEETROOT = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_beetroot"), BlockBehaviour.Properties.ofFullCopy(Blocks.STONE));
        GIANT_POISONOUS_POTATO = RegistryHelper.registerBlock(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_poisonous_potato"), BlockBehaviour.Properties.ofFullCopy(Blocks.STONE));
    }
}
