package dev.creoii.farmsandfriends.registry;

import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public final class FarmsAndFriendsItems {
    //public static Item MORTAR;
    //public static Item TROUGH;
    public static Item OVEN;
    //public static Item WHEATGRASS;
    //public static Item BAKED_CARROT;
    //public static Item BAKED_BREAD;
    //public static Item CHEESECAKE;
    //public static Item CHOCOLATE_CAKE;
    //public static Item CARROT_CAKE;
    //public static Item GOLDEN_APPLE_PIE;
    //public static Item GOLDEN_CARROT_CAKE;
    //public static Item SOUR_BERRY_PIE;
    //public static Item CHEESE;
    //public static Item MOLDY_CHEESE;
    public static Item CHEESE_WHEEL;
    public static Item MOLDY_CHEESE_WHEEL;
    public static Item APPLE_PIE;
    public static Item SWEET_BERRY_PIE;
    //public static Item BANANA_BREAD;
    //public static Item PUMPKIN_BREAD;
    //public static Item APPLE_JUICE;
    //public static Item SWEET_BERRY_JUICE;
    //public static Item SOUR_BERRY_JUICE;
    //public static Item CACTUS_JUICE;
    //public static Item CARROT_JUICE;
    public static Item MARIGOLD;
    public static Item ROSE;
    public static Item CYAN_ROSE;
    public static Item GIANT_POTATO;
    public static Item GIANT_CARROT;
    public static Item GIANT_BEETROOT;
    public static Item GIANT_POISONOUS_POTATO;

    public static void register() {
        OVEN = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "oven"), FarmsAndFriendsBlocks.OVEN);

        CHEESE_WHEEL = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "cheese_wheel"), FarmsAndFriendsBlocks.CHEESE_WHEEL);
        MOLDY_CHEESE_WHEEL = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "moldy_cheese_wheel"), FarmsAndFriendsBlocks.MOLDY_CHEESE_WHEEL);
        APPLE_PIE = RegistryHelper.registerItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "apple_pie"), new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(8).saturationModifier(.3f).build()));
        SWEET_BERRY_PIE = RegistryHelper.registerItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "sweet_berry_pie"), new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(8).saturationModifier(.3f).build()));

        ROSE = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "rose"), FarmsAndFriendsBlocks.ROSE);
        CYAN_ROSE = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "cyan_rose"), FarmsAndFriendsBlocks.CYAN_ROSE);
        MARIGOLD = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "marigold"), FarmsAndFriendsBlocks.MARIGOLD);

        GIANT_POTATO = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_potato"), FarmsAndFriendsBlocks.GIANT_POTATO);
        GIANT_CARROT = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_carrot"), FarmsAndFriendsBlocks.GIANT_CARROT);
        GIANT_BEETROOT = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_beetroot"), FarmsAndFriendsBlocks.GIANT_BEETROOT);
        GIANT_POISONOUS_POTATO = RegistryHelper.registerBlockItem(Identifier.fromNamespaceAndPath(GreatBigWorld.NAMESPACE, "giant_poisonous_potato"), FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO);

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(entries -> {
            entries.addAfter(Items.PUMPKIN_PIE, APPLE_PIE, SWEET_BERRY_PIE, CHEESE_WHEEL, MOLDY_CHEESE_WHEEL, GIANT_POTATO, GIANT_CARROT, GIANT_BEETROOT, GIANT_POISONOUS_POTATO);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(entries -> {
            entries.addAfter(Items.LILY_OF_THE_VALLEY, ROSE, MARIGOLD, CYAN_ROSE);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(entries -> {
            entries.addAfter(Items.SOUL_CAMPFIRE, OVEN);
        });
    }
}
