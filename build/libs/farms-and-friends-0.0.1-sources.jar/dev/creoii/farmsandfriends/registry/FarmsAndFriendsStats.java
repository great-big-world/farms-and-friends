package dev.creoii.farmsandfriends.registry;

import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class FarmsAndFriendsStats {
    public static class_2960 EAT_CHEESE_BITE;

    public static void register() {
        EAT_CHEESE_BITE = class_2378.method_10230(class_7923.field_41183, class_2960.method_60655(GreatBigWorld.NAMESPACE, "eat_cheese_bite"), class_2960.method_60655(GreatBigWorld.NAMESPACE, "eat_cheese_bite"));
    }
}
