package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.block.CheeseWheelBlock;
import dev.creoii.farmsandfriends.block.OvenBlock;
import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.minecraft.class_1294;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2356;
import net.minecraft.class_2465;
import net.minecraft.class_2960;
import net.minecraft.class_4970;

public final class FarmsAndFriendsBlocks {
    //public static Block MORTAR;
    //public static Block TROUGH;
    public static class_2248 OVEN;
    //public static Block WHEATGRASS;
    //public static Block ROTTEN_FLESH_BLOCK;
    public static class_2248 CHEESE_WHEEL;
    public static class_2248 MOLDY_CHEESE_WHEEL;
    //public static Block CHEESECAKE;
    //public static Block CHOCOLATE_CAKE;
    //public static Block CARROT_CAKE;
    //public static Block GOLDEN_APPLE_CAKE;
    //public static Block GOLDEN_CARROT_CAKE;
    //public static Block APPLE_PIE;
    //public static Block BERRY_PIE;
    public static class_2248 MARIGOLD;
    public static class_2248 ROSE;
    public static class_2248 CYAN_ROSE;
    public static class_2248 GIANT_POTATO;
    public static class_2248 GIANT_CARROT;
    public static class_2248 GIANT_BEETROOT;
    public static class_2248 GIANT_POISONOUS_POTATO;
    //public static Block GIANT_NETHER_WART;
    //public static Block GIANT_WHEAT;
    //public static Block GIANT_PUMPKIN; // 2x2 block
    //public static Block GIANT_MELON; // 2x2 block

    public static void register() {
        OVEN = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), OvenBlock::new, class_4970.class_2251.method_9630(class_2246.field_16333));

        CHEESE_WHEEL = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "cheese_wheel"), properties -> new CheeseWheelBlock(properties, false), class_4970.class_2251.method_9630(class_2246.field_10183));
        MOLDY_CHEESE_WHEEL = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "moldy_cheese_wheel"), properties -> new CheeseWheelBlock(properties, true), class_4970.class_2251.method_9630(class_2246.field_10183));

        ROSE = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "rose"), properties -> new class_2356(class_1294.field_5915, 1, properties), class_4970.class_2251.method_9630(class_2246.field_10449));
        CYAN_ROSE = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "cyan_rose"), properties -> new class_2356(class_1294.field_5915, 1, properties), class_4970.class_2251.method_9630(class_2246.field_10548));
        MARIGOLD = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "marigold"), properties -> new class_2356(class_1294.field_5915, 1, properties), class_4970.class_2251.method_9630(class_2246.field_10182));

        GIANT_POTATO = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_potato"), class_4970.class_2251.method_9630(class_2246.field_10340));
        GIANT_CARROT = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_carrot"), class_2465::new, class_4970.class_2251.method_9630(class_2246.field_10340));
        GIANT_BEETROOT = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_beetroot"), class_4970.class_2251.method_9630(class_2246.field_10340));
        GIANT_POISONOUS_POTATO = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_poisonous_potato"), class_4970.class_2251.method_9630(class_2246.field_10340));
    }
}
