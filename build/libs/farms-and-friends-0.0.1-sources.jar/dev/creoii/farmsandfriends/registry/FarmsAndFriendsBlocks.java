package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.block.OvenBlock;
import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;

public final class FarmsAndFriendsBlocks {
    public static class_2248 OVEN;

    public static void register() {
        OVEN = RegistryHelper.registerBlock(class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), OvenBlock::new, class_4970.class_2251.method_9630(class_2246.field_16333));
    }
}
