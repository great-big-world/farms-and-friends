package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.client.OvenScreen;
import dev.creoii.farmsandfriends.menu.OvenMenu;
import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class FarmsAndFriendsScreens {
    public static class_3917<OvenMenu> OVEN;

    public static void register() {
        OVEN = class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), new class_3917<>(OvenMenu::new, class_7701.field_40182));
    }

    public static void registerClient() {
        class_3929.method_17542(OVEN, OvenScreen::new);
    }
}
