package dev.creoii.farmsandfriends.registry;

import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7706;

public final class FarmsAndFriendsItems {
    public static class_1792 OVEN;
    //public static Item BAKED_CARROT;
    //public static Item BAKED_BREAD;
    //public static Item CARROT_CAKE;
    //public static Item GOLDEN_APPLE_PIE;
    //public static Item GOLDEN_CARROT_CAKE;
    public static class_1792 APPLE_PIE;
    public static class_1792 SWEET_BERRY_PIE;
    public static class_1792 GLOW_BERRY_PIE;
    public static class_1792 PUMPKIN_BREAD;

    public static void register() {
        OVEN = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), FarmsAndFriendsBlocks.OVEN);

        APPLE_PIE = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "apple_pie"), new class_1792.class_1793().method_7889(16).method_19265(new class_4174.class_4175().method_19238(8).method_19237(.3f).method_19242()));
        SWEET_BERRY_PIE = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "sweet_berry_pie"), new class_1792.class_1793().method_7889(16).method_19265(new class_4174.class_4175().method_19238(8).method_19237(.3f).method_19242()));
        GLOW_BERRY_PIE = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "glow_berry_pie"), new class_1792.class_1793().method_7889(16).method_19265(new class_4174.class_4175().method_19238(8).method_19237(.3f).method_19242()));
        PUMPKIN_BREAD = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "pumpkin_bread"), new class_1792.class_1793().method_19265(new class_4174.class_4175().method_19238(6).method_19237(.5f).method_19242()));

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> {
            entries.addAfter(class_1802.field_8741, APPLE_PIE, SWEET_BERRY_PIE, GLOW_BERRY_PIE);
            entries.addAfter(class_1802.field_8229, PUMPKIN_BREAD);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(class_1802.field_23842, OVEN);
        });
    }
}
