package dev.creoii.farmsandfriends.registry;

import dev.creoii.greatbigworld.GreatBigWorld;
import dev.creoii.greatbigworld.util.RegistryHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7706;

public final class FarmsAndFriendsItems {
    //public static Item MORTAR;
    //public static Item TROUGH;
    public static class_1792 OVEN;
    //public static Item WHEATGRASS;
    //public static Item BAKED_CARROT;
    //public static Item BAKED_BREAD;
    //public static Item CHEESECAKE;
    //public static Item CHOCOLATE_CAKE;
    //public static Item CARROT_CAKE;
    //public static Item GOLDEN_APPLE_PIE;
    //public static Item GOLDEN_CARROT_CAKE;
    //public static Item SOUR_BERRY_PIE;
    //public static Item CHEESE;
    //public static Item MOLDY_CHEESE;
    public static class_1792 CHEESE_WHEEL;
    public static class_1792 MOLDY_CHEESE_WHEEL;
    public static class_1792 APPLE_PIE;
    public static class_1792 SWEET_BERRY_PIE;
    //public static Item BANANA_BREAD;
    //public static Item PUMPKIN_BREAD;
    //public static Item APPLE_JUICE;
    //public static Item SWEET_BERRY_JUICE;
    //public static Item SOUR_BERRY_JUICE;
    //public static Item CACTUS_JUICE;
    //public static Item CARROT_JUICE;
    public static class_1792 MARIGOLD;
    public static class_1792 ROSE;
    public static class_1792 CYAN_ROSE;
    public static class_1792 GIANT_POTATO;
    public static class_1792 GIANT_CARROT;
    public static class_1792 GIANT_BEETROOT;
    public static class_1792 GIANT_POISONOUS_POTATO;

    public static void register() {
        OVEN = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), FarmsAndFriendsBlocks.OVEN);

        CHEESE_WHEEL = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "cheese_wheel"), FarmsAndFriendsBlocks.CHEESE_WHEEL);
        MOLDY_CHEESE_WHEEL = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "moldy_cheese_wheel"), FarmsAndFriendsBlocks.MOLDY_CHEESE_WHEEL);
        APPLE_PIE = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "apple_pie"), new class_1792.class_1793().method_7889(16).method_19265(new class_4174.class_4175().method_19238(8).method_19237(.3f).method_19242()));
        SWEET_BERRY_PIE = RegistryHelper.registerItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "sweet_berry_pie"), new class_1792.class_1793().method_7889(16).method_19265(new class_4174.class_4175().method_19238(8).method_19237(.3f).method_19242()));

        ROSE = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "rose"), FarmsAndFriendsBlocks.ROSE);
        CYAN_ROSE = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "cyan_rose"), FarmsAndFriendsBlocks.CYAN_ROSE);
        MARIGOLD = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "marigold"), FarmsAndFriendsBlocks.MARIGOLD);

        GIANT_POTATO = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_potato"), FarmsAndFriendsBlocks.GIANT_POTATO);
        GIANT_CARROT = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_carrot"), FarmsAndFriendsBlocks.GIANT_CARROT);
        GIANT_BEETROOT = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_beetroot"), FarmsAndFriendsBlocks.GIANT_BEETROOT);
        GIANT_POISONOUS_POTATO = RegistryHelper.registerBlockItem(class_2960.method_60655(GreatBigWorld.NAMESPACE, "giant_poisonous_potato"), FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> {
            entries.addAfter(class_1802.field_8741, APPLE_PIE, SWEET_BERRY_PIE, CHEESE_WHEEL, MOLDY_CHEESE_WHEEL, GIANT_POTATO, GIANT_CARROT, GIANT_BEETROOT, GIANT_POISONOUS_POTATO);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(entries -> {
            entries.addAfter(class_1802.field_17514, ROSE, MARIGOLD, CYAN_ROSE);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(class_1802.field_23842, OVEN);
        });
    }
}
