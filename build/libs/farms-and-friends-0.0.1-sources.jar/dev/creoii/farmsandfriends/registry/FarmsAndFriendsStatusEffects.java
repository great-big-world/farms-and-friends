package dev.creoii.farmsandfriends.registry;

public final class FarmsAndFriendsStatusEffects {
    //public static MobEffect SUGARED; // spring when on low hunger

    public static void register() {

    }
}
