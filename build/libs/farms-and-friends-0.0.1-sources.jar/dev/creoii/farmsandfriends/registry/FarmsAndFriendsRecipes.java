package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.recipe.OvenRecipe;
import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_10290;
import net.minecraft.class_10355;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public final class FarmsAndFriendsRecipes {
    public static class_1865<OvenRecipe> OVEN;
    public static class_3956<OvenRecipe> OVEN_TYPE;
    public static final class_5321<class_10290> OVEN_INPUT = class_5321.method_29179(class_10290.field_54646, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven_input"));
    public static final class_10355 OVEN_CATEGORY = new class_10355();

    public static void register() {
        OVEN = class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), new OvenRecipe.Serializer(OvenRecipe::new, 200));

        OVEN_TYPE = class_2378.method_10230(class_7923.field_41188, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), new class_3956<>() {
            public String toString() {
                return "oven";
            }
        });
        class_2378.method_10230(class_7923.field_54927, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), OVEN_CATEGORY);
    }
}
