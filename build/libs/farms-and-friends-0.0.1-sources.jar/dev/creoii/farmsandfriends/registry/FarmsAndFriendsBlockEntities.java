package dev.creoii.farmsandfriends.registry;

import dev.creoii.farmsandfriends.block.entity.OvenBlockEntity;
import dev.creoii.greatbigworld.GreatBigWorld;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class FarmsAndFriendsBlockEntities {
    public static class_2591<OvenBlockEntity> OVEN;

    public static void register() {
        OVEN = class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(GreatBigWorld.NAMESPACE, "oven"), FabricBlockEntityTypeBuilder.create(OvenBlockEntity::new, FarmsAndFriendsBlocks.OVEN).build());
    }
}
