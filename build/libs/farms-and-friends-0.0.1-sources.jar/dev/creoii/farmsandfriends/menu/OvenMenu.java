package dev.creoii.farmsandfriends.menu;

import dev.creoii.farmsandfriends.recipe.OvenRecipe;
import dev.creoii.farmsandfriends.recipe.OvenRecipeInput;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsRecipes;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsScreens;
import dev.creoii.farmsandfriends.util.FarmsAndFriendsRecipeBookTypes;
import dev.creoii.farmsandfriends.util.OvenFuelSlot;
import net.minecraft.class_10290;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1719;
import net.minecraft.class_1729;
import net.minecraft.class_1735;
import net.minecraft.class_1737;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2955;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.class_5421;
import net.minecraft.class_8786;
import net.minecraft.class_9875;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.crafting.*;
import java.util.ArrayList;
import java.util.List;

public class OvenMenu extends class_1729 {
    final class_1263 container;
    private final class_3913 data;
    protected final class_1937 level;
    private final class_10290 acceptedInputs;

    public OvenMenu(int i, class_1661 inventory) {
        this(i, inventory, new class_1277(8), new class_3919(4));
    }

    public OvenMenu(int i, class_1661 inventory, class_1263 container, class_3913 containerData) {
        super(FarmsAndFriendsScreens.OVEN, i);
        method_17359(container, 8);
        method_17361(containerData, 4);
        this.container = container;
        data = containerData;
        level = inventory.field_7546.method_73183();
        acceptedInputs = level.method_8433().method_64678(FarmsAndFriendsRecipes.OVEN_INPUT);
        method_7621(new class_1735(container, 0, 30, 16));
        method_7621(new class_1735(container, 1, 48, 16));
        method_7621(new class_1735(container, 2, 66, 16));
        method_7621(new class_1735(container, 3, 30, 34));
        method_7621(new class_1735(container, 4, 48, 34));
        method_7621(new class_1735(container, 5, 66, 34));
        method_7621(new OvenFuelSlot(this, container, 6, 48, 55));
        method_7621(new class_1719(inventory.field_7546, container, 7, 124, 34));
        method_61624(inventory, 8, 84);
        method_17360(containerData);
    }

    public void method_7654(class_9875 stackedItemContents) {
        if (container instanceof class_1737 compatible) {
            compatible.method_7683(stackedItemContents);
        }
    }

    public class_1735 getResultSlot() {
        return field_7761.get(7);
    }

    public boolean method_7597(class_1657 player) {
        return container.method_5443(player);
    }

    public class_1799 method_7601(class_1657 player, int i) {
        class_1799 itemStack = class_1799.field_8037;
        class_1735 slot = field_7761.get(i);

        if (slot != null && slot.method_7681()) {
            class_1799 stack = slot.method_7677();
            itemStack = stack.method_7972();

            if (i == 7) {
                if (!method_7616(stack, 8, 44, true)) {
                    return class_1799.field_8037;
                }
                slot.method_7670(stack, itemStack);
            } else if (i >= 8) {
                if (canSmelt(stack)) {
                    if (!method_7616(stack, 0, 5, false)) {
                        return class_1799.field_8037;
                    }
                } else if (isFuel(stack)) {
                    if (!method_7616(stack, 6, 7, false)) {
                        return class_1799.field_8037;
                    }
                } else if (i < 35) { // inventory → hotbar
                    if (!method_7616(stack, 35, 44, false)) {
                        return class_1799.field_8037;
                    }
                } else if (!method_7616(stack, 8, 35, false)) { // hotbar → inventory
                    return class_1799.field_8037;
                }
            } else {
                if (!method_7616(stack, 8, 44, false)) {
                    return class_1799.field_8037;
                }
            }

            if (stack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (stack.method_7947() == itemStack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, stack);
        }

        return itemStack;
    }

    protected boolean canSmelt(class_1799 itemStack) {
        return acceptedInputs.method_64701(itemStack);
    }

    public boolean isFuel(class_1799 itemStack) {
        return level.method_61269().method_61752(itemStack);
    }

    public float getBurnProgress() {
        int i = data.method_17390(2);
        int j = data.method_17390(3);
        return j != 0 && i != 0 ? class_3532.method_15363((float)i / (float)j, 0f, 1f) : 0f;
    }

    public float getLitProgress() {
        int i = data.method_17390(1);
        if (i == 0) {
            i = 200;
        }

        return class_3532.method_15363((float)data.method_17390(0) / (float)i, 0f, 1f);
    }

    public boolean isLit() {
        return data.method_17390(0) > 0;
    }

    public class_5421 method_30264() {
        return FarmsAndFriendsRecipeBookTypes.OVEN;
    }

    @Override
    @SuppressWarnings("unchecked")
    public class_9885 method_17697(boolean bl, boolean bl2, class_8786<?> recipeHolder, class_3218 serverLevel, class_1661 inventory) {
        final List<class_1735> inputs = List.of(method_7611(0), method_7611(1), method_7611(2), method_7611(3), method_7611(4), method_7611(5));
        final List<class_1735> slots = List.of(method_7611(0), method_7611(1), method_7611(2), method_7611(3), method_7611(4), method_7611(5), method_7611(7));
        return class_2955.method_61232(new OvenMenuAccess(inputs), 3, 2, slots, inputs, inventory, (class_8786<OvenRecipe>) recipeHolder, bl, bl2);
    }

    public class OvenMenuAccess implements class_2955.class_9840<OvenRecipe> {
        private final List<class_1735> list;

        public OvenMenuAccess(List<class_1735> list) {
            this.list = list;
        }

        @Override
        public void method_61237(class_9875 stackedItemContents) {
            OvenMenu.this.method_7654(stackedItemContents);
        }

        @Override
        public void method_61236() {
            list.forEach(slot -> slot.method_7673(class_1799.field_8037));
        }

        @Override
        public boolean method_61238(class_8786<OvenRecipe> recipeHolder) {
            List<class_1799> itemStacks = new ArrayList<>();
            for (int i = 0; i < 6; ++i) {
                itemStacks.add(OvenMenu.this.container.method_5438(i));
            }
            return recipeHolder.comp_1933().matches(new OvenRecipeInput(itemStacks), OvenMenu.this.level);
        }
    }
}
