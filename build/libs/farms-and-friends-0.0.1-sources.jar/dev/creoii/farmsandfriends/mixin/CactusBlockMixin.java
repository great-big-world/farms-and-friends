package dev.creoii.farmsandfriends.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2246;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2266.class)
public class CactusBlockMixin {
    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextDouble()D"))
    private double gbw$fasterCactusFlowers(class_5819 instance, Operation<Double> original, @Local(argsOnly = true) class_3218 serverLevel, @Local(argsOnly = true) class_2338 blockPos) {
        double d = original.call(instance);
        class_2338 pos;
        for (int yo = 0; yo < 5; ++yo) {
            pos = blockPos.method_10086(yo);

            if (!serverLevel.method_8320(pos).method_45474()) return d;
            else if (serverLevel.method_8320(pos).method_27852(class_2246.field_10503)) return 0d;
        }
        return d;
    }
}
