package dev.creoii.farmsandfriends.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2680;

@Mixin(class_2344.class)
public abstract class FarmBlockMixin extends class_2248 {
    public FarmBlockMixin(class_2251 properties) {
        super(properties);
    }

    @Inject(method = "fallOn", at = @At("HEAD"), cancellable = true)
    private void gbw$strengthFertilize(class_1937 level, class_2680 blockState, class_2338 blockPos, class_1297 entity, double d, CallbackInfo ci) {
        //if (!level.isClientSide()) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.REPLANT, List.of()).contains(level.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    double chance = Math.pow(j / 4d, 2d);
        //    if (level.random.nextDouble() < chance) {
        //        super.fallOn(level, blockState, blockPos, entity, d);
        //        ci.cancel();
        //    }
        //}
    }
}
