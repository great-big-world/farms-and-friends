package dev.creoii.farmsandfriends.mixin.client;

import dev.creoii.farmsandfriends.registry.FarmsAndFriendsRecipes;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.class_10331;
import net.minecraft.class_10355;

@Mixin(class_10331.class)
public class SearchRecipeBookCategoryMixin {
    @SuppressWarnings("InvokerTarget")
    @Invoker("<init>")
    private static class_10331 create(String internalName, int internalId, class_10355... categories) {
        throw new AssertionError();
    }

    @Shadow @Final @Mutable private static class_10331[] $VALUES;

    @Inject(method = "<clinit>", at = @At(value = "FIELD", opcode = Opcodes.PUTSTATIC, target = "Lnet/minecraft/client/gui/screens/recipebook/SearchRecipeBookCategory;$VALUES:[Lnet/minecraft/client/gui/screens/recipebook/SearchRecipeBookCategory;", shift = At.Shift.AFTER))
    private static void addCustomRecipeBookGroup(CallbackInfo ci) {
        ArrayList<class_10331> values = new ArrayList<>(Arrays.asList($VALUES));
        int last = values.size();

        class_10331 kiln = create("GBW_OVEN", last, FarmsAndFriendsRecipes.OVEN_CATEGORY);
        values.add(kiln);

        $VALUES = values.toArray(new class_10331[0]);
    }
}
