package dev.creoii.farmsandfriends.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_10777;
import net.minecraft.class_1767;
import net.minecraft.class_6012;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_10777.class)
public class SheepColorSpawnRulesMixin {
    @WrapOperation(method = "commonColors", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/random/WeightedList$Builder;build()Lnet/minecraft/util/random/WeightedList;"))
    private static class_6012<class_10777.class_10778> gbw$addRareGreenSheep(class_6012.class_6006<class_10777.class_10778> instance, Operation<class_6012<class_10777.class_10778>> original) {
        return original.call(instance.method_34975(_ -> class_1767.field_7942, 1));
    }
}
