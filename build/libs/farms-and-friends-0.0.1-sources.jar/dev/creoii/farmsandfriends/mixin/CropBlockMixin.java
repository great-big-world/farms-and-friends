package dev.creoii.farmsandfriends.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsBlocks;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

@Mixin(class_2302.class)
public abstract class CropBlockMixin extends class_2248 {
    @Shadow public abstract int getMaxAge();

    @Shadow
    public abstract class_2680 getStateForAge(int i);

    public CropBlockMixin(class_2251 properties) {
        super(properties);
    }

    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/CropBlock;getGrowthSpeed(Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)F"))
    private float gbw$fertilizeGrowthSpeed(class_2248 block, class_1922 blockGetter, class_2338 blockPos, Operation<Float> original) {
        float f = original.call(block, blockGetter, blockPos);

        int i = 1;
        //for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //    if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.SPEED, List.of()).contains(blockGetter.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //        f *= 6.25f - i++;
        //    }
        //}

        return f;
    }

    @WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private boolean gbw$fertilizeOvergrowth(class_3218 instance, class_2338 blockPos, class_2680 blockState, int i, Operation<Boolean> original) {
        //if (i == getMaxAge() && FertilizerUtils.OVERGROWN_CROPS.containsKey(this)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.OVERGROWTH, List.of()).contains(instance.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    if (instance.random.nextDouble() < Math.pow(j / 5d, 2d)) {
        //        BlockState state = FertilizerUtils.OVERGROWN_CROPS.get(this).defaultBlockState();
//
        //        if (state.is(FarmsAndFriendsBlocks.GIANT_POTATO) && instance.random.nextFloat() < .02f)
        //            state = FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO.defaultBlockState();
//
        //        return original.call(instance, blockPos, state, i);
        //    }
        //}
        return original.call(instance, blockPos, blockState, i);
    }

    @WrapOperation(method = "growCrops", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private boolean gbw$fertilizeOvergrowthBonemeal(class_1937 instance, class_2338 blockPos, class_2680 blockState, int i, Operation<Boolean> original) {
        //if (i == getMaxAge() && FertilizerUtils.OVERGROWN_CROPS.containsKey(this)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.OVERGROWTH, List.of()).contains(instance.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    if (instance.random.nextDouble() < Math.pow(j / 5d, 2d)) {
        //        BlockState state = FertilizerUtils.OVERGROWN_CROPS.get(this).defaultBlockState();
//
        //        if (state.is(FarmsAndFriendsBlocks.GIANT_POTATO) && instance.random.nextFloat() < .02f)
        //            state = FarmsAndFriendsBlocks.GIANT_POISONOUS_POTATO.defaultBlockState();
//
        //        return original.call(instance, blockPos, state, i);
        //    }
        //}
        return original.call(instance, blockPos, blockState, i);
    }

    @Override
    public void method_9556(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState, @Nullable class_2586 blockEntity, class_1799 itemStack) {
        //if (canSurvive(blockState, level, blockPos)) {
        //    int j = 0;
        //    for (BlockPos offset : FertilizerUtils.OFFSETS) {
        //        if (FertilizerUtils.FERTILIZERS.getOrDefault(FertilizerUtils.FertilizerType.REPLANT, List.of()).contains(level.getBlockState(blockPos.offset(offset).below()).getBlock())) {
        //            ++j;
        //        }
        //    }
//
        //    double chance = Math.pow(j / 4d, 2d);
        //    if (level.random.nextDouble() < chance) {
        //        level.setBlock(blockPos, getStateForAge(0), 2);
        //    }
        //}
        super.method_9556(level, player, blockPos, blockState, blockEntity, itemStack);
    }
}
