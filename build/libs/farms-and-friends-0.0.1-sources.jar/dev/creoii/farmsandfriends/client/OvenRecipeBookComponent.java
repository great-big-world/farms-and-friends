package dev.creoii.farmsandfriends.client;

import java.util.List;

import dev.creoii.farmsandfriends.menu.OvenMenu;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10294;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_507;
import net.minecraft.class_516;
import net.minecraft.class_8666;
import net.minecraft.class_9875;
import net.minecraft.class_9934;

@Environment(EnvType.CLIENT)
public class OvenRecipeBookComponent extends class_507<OvenMenu> {
    private static final class_8666 FILTER_SPRITES = new class_8666(class_2960.method_60656("recipe_book/furnace_filter_enabled"), class_2960.method_60656("recipe_book/furnace_filter_disabled"), class_2960.method_60656("recipe_book/furnace_filter_enabled_highlighted"), class_2960.method_60656("recipe_book/furnace_filter_disabled_highlighted"));
    private final class_2561 recipeFilterName;

    public OvenRecipeBookComponent(OvenMenu menu, class_2561 component, List<class_507.class_10329> list) {
        super(menu, list);
        this.recipeFilterName = component;
    }

    protected class_8666 method_76629() {
        return FILTER_SPRITES;
    }

    protected boolean method_62023(class_1735 slot) {
        return switch (slot.field_7874) {
            case 0, 1, 2 -> true;
            default -> false;
        };
    }

    protected void method_64868(class_9934 ghostSlots, class_10295 recipeDisplay, class_10352 contextMap) {
        ghostSlots.method_64874(field_3095.getResultSlot(), contextMap, recipeDisplay.comp_3258());
        if (recipeDisplay instanceof class_10294 furnaceRecipeDisplay) {
            ghostSlots.method_64872(field_3095.field_7761.get(0), contextMap, furnaceRecipeDisplay.comp_3256());
            class_1735 slot = field_3095.field_7761.get(1);
            if (slot.method_7677().method_7960()) {
                ghostSlots.method_64872(slot, contextMap, furnaceRecipeDisplay.comp_3257());
            }
        }
    }

    protected class_2561 method_17064() {
        return recipeFilterName;
    }

    protected void method_62024(class_516 recipeCollection, class_9875 stackedItemContents) {
        recipeCollection.method_64884(stackedItemContents, (recipeDisplay) -> recipeDisplay instanceof class_10294);
    }
}
