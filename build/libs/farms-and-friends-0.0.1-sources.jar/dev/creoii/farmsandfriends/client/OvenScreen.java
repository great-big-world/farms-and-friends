package dev.creoii.farmsandfriends.client;

import dev.creoii.farmsandfriends.menu.OvenMenu;
import dev.creoii.farmsandfriends.util.FarmsAndFriendsSearchRecipeBookCategories;
import dev.creoii.greatbigworld.GreatBigWorld;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10260;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_507;
import net.minecraft.class_8029;
import java.util.List;

@Environment(EnvType.CLIENT)
public class OvenScreen extends class_10260<OvenMenu> {
    private static final class_2960 LIT_PROGRESS_LEFT_SPRITE = class_2960.method_60655(GreatBigWorld.NAMESPACE, "container/oven/lit_progress_left");
    private static final class_2960 LIT_PROGRESS_RIGHT_SPRITE = class_2960.method_60655(GreatBigWorld.NAMESPACE, "container/oven/lit_progress_right");
    private static final class_2960 BURN_PROGRESS_SPRITE = class_2960.method_60655(GreatBigWorld.NAMESPACE, "container/oven/burn_progress");
    private static final class_2960 TEXTURE = class_2960.method_60655(GreatBigWorld.NAMESPACE, "textures/gui/container/oven.png");
    private static final class_2561 FILTER_NAME = class_2561.method_43471("gui.recipebook.toggleRecipes.cookable");
    private static final List<class_507.class_10329> TABS = List.of(new class_507.class_10329(FarmsAndFriendsSearchRecipeBookCategories.OVEN));

    public OvenScreen(OvenMenu ovenMenu, class_1661 inventory, class_2561 component) {
        super(ovenMenu, new OvenRecipeBookComponent(ovenMenu, FILTER_NAME, TABS), inventory, component);
    }

    public void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    protected class_8029 method_64509() {
        return new class_8029(field_2776 + 6, field_22790 / 2 - 60);
    }

    protected void method_2389(class_332 guiGraphics, float f, int i, int j) {
        int k = field_2776;
        int l = field_2800;
        guiGraphics.method_25290(class_10799.field_56883, TEXTURE, k, l, 0f, 0f, field_2792, field_2779, 256, 256);
        if (field_2797.isLit()) {
            int n = class_3532.method_15386(field_2797.getLitProgress() * 15f);
            guiGraphics.method_70846(class_10799.field_56883, LIT_PROGRESS_LEFT_SPRITE, 19, 15, 0, 15 - n, k + 27, l + 54 + 15 - n, 19, n);
            guiGraphics.method_70846(class_10799.field_56883, LIT_PROGRESS_RIGHT_SPRITE, 19, 15, 0, 15 - n, k + 67, l + 54 + 15 - n, 19, n);
        }

        int n = class_3532.method_15386(field_2797.getBurnProgress() * 24f);
        guiGraphics.method_70846(class_10799.field_56883, BURN_PROGRESS_SPRITE, 24, 16, 0, 0, k + 89, l + 34, n, 16);
    }
}
