package dev.creoii.farmsandfriends.client;

import dev.creoii.farmsandfriends.registry.FarmsAndFriendsScreens;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;

public class FarmsAndFriendsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FarmsAndFriendsScreens.registerClient();

        BlockRenderLayerMap.putBlocks(class_11515.field_60925);
    }
}
