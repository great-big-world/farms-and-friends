package dev.creoii.farmsandfriends.recipe;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_9695;
import net.minecraft.class_9875;

public class OvenRecipeInput implements class_9695 {
    private final List<class_1799> items;
    private final class_9875 contents = new class_9875();
    private final int ingredientCount;

    public OvenRecipeInput(List<class_1799> items) {
        this.items = items;
        int count = 0;

        for (class_1799 stack : items) {
            if (!stack.method_7960()) {
                count++;
                contents.method_61536(stack, 1);
            }
        }

        this.ingredientCount = count;
    }

    @Override
    public class_1799 method_59984(int index) {
        return items.get(index);
    }

    @Override
    public int method_59983() {
        return items.size();
    }

    public class_9875 stackedContents() {
        return contents;
    }

    public int ingredientCount() {
        return ingredientCount;
    }
}