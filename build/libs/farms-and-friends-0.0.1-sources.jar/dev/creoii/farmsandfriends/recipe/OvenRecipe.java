package dev.creoii.farmsandfriends.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsItems;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsRecipes;
import net.minecraft.class_10294;
import net.minecraft.class_10295;
import net.minecraft.class_10302;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7709;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9887;
import net.minecraft.world.item.crafting.*;
import org.jspecify.annotations.Nullable;

import java.util.List;

public class OvenRecipe implements class_1860<OvenRecipeInput> {
    private final List<class_1856> ingredients;
    private final class_1799 result;
    private final String group;
    private final class_7709 category;
    private final float experience;
    private final int cookingTime;
    private @Nullable class_9887 placementInfo;

    public OvenRecipe(String group, class_7709 category, List<class_1856> ingredients, class_1799 result, float experience, int cookingTime) {
        this.group = group;
        this.category = category;
        this.ingredients = ingredients;
        this.result = result;
        this.experience = experience;
        this.cookingTime = cookingTime;
    }

    public class_1799 result() {
        return result;
    }

    public List<class_1856> ingredients() {
        return ingredients;
    }

    public float experience() {
        return this.experience;
    }

    public int cookingTime() {
        return this.cookingTime;
    }

    public class_7709 category() {
        return this.category;
    }

    @Override
    public String method_8112() {
        return group;
    }

    public List<class_10295> method_64664() {
        return List.of(new class_10294(ingredients.getFirst().method_64673(), class_10302.class_10303.field_54674, new class_10302.class_10307(result), new class_10302.class_10306(FarmsAndFriendsItems.OVEN), cookingTime, experience));
    }

    public class_1865<OvenRecipe> method_8119() {
        return FarmsAndFriendsRecipes.OVEN;
    }

    public class_3956<OvenRecipe> method_17716() {
        return FarmsAndFriendsRecipes.OVEN_TYPE;
    }

    @Override
    public boolean matches(OvenRecipeInput recipeInput, class_1937 level) {
        if (recipeInput.ingredientCount() != ingredients.size()) {
            return false;
        }
        return recipeInput.stackedContents().method_61538(this, null);
    }

    @Override
    public class_1799 assemble(OvenRecipeInput recipeInput, class_7225.class_7874 provider) {
        return result.method_7972();
    }

    @Override
    public class_9887 method_61671() {
        if (placementInfo == null) {
            placementInfo = class_9887.method_61686(ingredients);
        }
        return placementInfo;
    }

    public class_10355 method_64668() {
        return FarmsAndFriendsRecipes.OVEN_CATEGORY;
    }

    public static class Serializer implements class_1865<dev.creoii.farmsandfriends.recipe.OvenRecipe> {
        private final MapCodec<OvenRecipe> codec;
        private final class_9139<class_9129, OvenRecipe> streamCodec;

        public Serializer(OvenRecipe.Factory<OvenRecipe> factory, int i) {
            this.codec = RecordCodecBuilder.mapCodec(instance -> {
                return instance.group(
                        Codec.STRING.optionalFieldOf("group", "").forGetter(OvenRecipe::method_8112),
                        class_7709.field_40245.fieldOf("category").orElse(class_7709.field_40244).forGetter(OvenRecipe::category),
                        class_1856.field_46095.listOf(1, 6).fieldOf("ingredients").forGetter(OvenRecipe::ingredients),
                        class_1799.field_51397.fieldOf("result").forGetter(OvenRecipe::result),
                        Codec.FLOAT.fieldOf("experience").orElse(0f).forGetter(OvenRecipe::experience),
                        Codec.INT.fieldOf("cookingtime").orElse(i).forGetter(OvenRecipe::cookingTime)
                ).apply(instance, factory::create);
            });

            streamCodec = class_9139.method_58025(
                    class_9135.field_48554, OvenRecipe::method_8112,
                    class_7709.field_54631, OvenRecipe::category,
                    class_1856.field_48355.method_56433(class_9135.method_56363()), OvenRecipe::ingredients,
                    class_1799.field_48349, OvenRecipe::result,
                    class_9135.field_48552, OvenRecipe::experience,
                    class_9135.field_49675, OvenRecipe::cookingTime,
                    factory::create);
        }

        public MapCodec<OvenRecipe> method_53736() {
            return codec;
        }

        public class_9139<class_9129, OvenRecipe> method_56104() {
            return streamCodec;
        }
    }

    @FunctionalInterface
    public interface Factory<T extends OvenRecipe> {
        T create(String group, class_7709 category, List<class_1856> ingredients, class_1799 itemStack, float experience, int cookingTime);
    }
}
