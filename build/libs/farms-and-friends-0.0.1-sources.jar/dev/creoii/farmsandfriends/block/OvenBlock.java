package dev.creoii.farmsandfriends.block;

import com.mojang.serialization.MapCodec;
import dev.creoii.farmsandfriends.block.entity.OvenBlockEntity;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsBlockEntities;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jspecify.annotations.Nullable;

public class OvenBlock extends class_2363 {
    public static final class_265 BODY = class_2248.method_9541(0d, 1d, 0d, 16d, 12d, 16d);
    public static final class_265 FEET = class_259.method_17786(class_2248.method_9541(0d, 0d, 0d, 3d, 1d, 3d), class_2248.method_9541(13d, 0d, 0d, 16d, 1d, 3d), class_2248.method_9541(0d, 0d, 13d, 3d, 1d, 16d), class_2248.method_9541(13d, 0d, 13d, 16d, 1d, 16d));
    public static final class_265 CHIMNEY = class_2248.method_9541(5d, 12d, 5d, 11d, 16d, 11d);
    public static final class_265 SHAPE = class_259.method_17786(BODY, FEET, CHIMNEY);
    public static final MapCodec<OvenBlock> CODEC = method_54094(OvenBlock::new);

    public MapCodec<OvenBlock> method_53969() {
        return field_46280;
    }

    public OvenBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    @Override
    protected class_265 method_9530(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        return SHAPE;
    }

    @Override
    protected class_265 method_9549(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        return SHAPE;
    }

    public class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return new OvenBlockEntity(blockPos, blockState);
    }

    public <T extends class_2586> @Nullable class_5558<T> method_31645(class_1937 level, class_2680 blockState, class_2591<T> blockEntityType) {
        if (level instanceof class_3218 serverLevel) {
            return method_31618(blockEntityType, FarmsAndFriendsBlockEntities.OVEN, (levelx, blockPos, state, abstractFurnaceBlockEntity) -> OvenBlockEntity.serverTick(serverLevel, blockPos, state, abstractFurnaceBlockEntity));
        } else return null;
    }

    protected void method_17025(class_1937 level, class_2338 blockPos, class_1657 player) {
        class_2586 blockEntity = level.method_8321(blockPos);
        if (blockEntity instanceof OvenBlockEntity) {
            player.method_17355((class_3908) blockEntity);
            player.method_7281(class_3468.field_15379);
        }
    }

    public void method_9496(class_2680 blockState, class_1937 level, class_2338 blockPos, class_5819 randomSource) {
        if (blockState.method_11654(field_11105)) {
            double d = (double)blockPos.method_10263() + (double).5F;
            double e = blockPos.method_10264() + .25d;
            double f = (double)blockPos.method_10260() + (double).5F;
            if (randomSource.method_43058() < .1d) {
                level.method_8486(d, e, f, class_3417.field_15006, class_3419.field_15245, 1f, 1f, false);
            }

            class_2350 direction = blockState.method_11654(field_11104);
            class_2350.class_2351 axis = direction.method_10166();
            double h = randomSource.method_43058() * .6d - .3d;
            double i = axis == class_2350.class_2351.field_11048 ? (double)direction.method_10148() * .52d : h;
            double j = randomSource.method_43058() * (double)6f / (double)16f;
            double k = axis == class_2350.class_2351.field_11051 ? (double)direction.method_10165() * .52d : h;
            level.method_8406(class_2398.field_11251, d + i, e + j, f + k, 0f, 0f, 0f);
            level.method_8406(class_2398.field_11240, d + i, e + j, f + k, 0f, 0f, 0f);
        }
    }
}
