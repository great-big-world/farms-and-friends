package dev.creoii.farmsandfriends.block.entity;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import dev.creoii.farmsandfriends.menu.OvenMenu;
import dev.creoii.farmsandfriends.recipe.OvenRecipe;
import dev.creoii.farmsandfriends.recipe.OvenRecipeInput;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsBlockEntities;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsRecipes;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1732;
import net.minecraft.class_1737;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3913;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_8786;
import net.minecraft.class_9875;
import net.minecraft.class_9895;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.crafting.*;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Map;

public class OvenBlockEntity extends class_2624 implements class_1278, class_1732, class_1737 {
    private static final Codec<Map<class_5321<class_1860<?>>, Integer>> RECIPES_USED_CODEC = Codec.unboundedMap(class_1860.field_56667, Codec.INT);
    private static final int[] SLOTS_FOR_UP = new int[]{0, 1, 2, 3, 4, 5};
    private static final int[] SLOTS_FOR_DOWN = new int[]{7, 6};
    private static final int[] SLOTS_FOR_SIDES = new int[]{6};
    private static final class_2561 DEFAULT_NAME = class_2561.method_43471("container.oven");
    private class_2371<class_1799> items;
    private int litTimeRemaining;
    private int litTotalTime;
    private int cookingTimer;
    private int cookingTotalTime;
    private  final class_3913 dataAccess;
    private final Reference2IntOpenHashMap<class_5321<class_1860<?>>> recipesUsed;
    private final class_1863.class_7266<OvenRecipeInput, OvenRecipe> quickCheck;

    public OvenBlockEntity(class_2338 blockPos, class_2680 blockState) {
        super(FarmsAndFriendsBlockEntities.OVEN, blockPos, blockState);
        items = class_2371.method_10213(8, class_1799.field_8037);
        dataAccess = new class_3913() {
            public int method_17390(int i) {
                return switch (i) {
                    case 0 -> OvenBlockEntity.this.litTimeRemaining;
                    case 1 -> OvenBlockEntity.this.litTotalTime;
                    case 2 -> OvenBlockEntity.this.cookingTimer;
                    case 3 -> OvenBlockEntity.this.cookingTotalTime;
                    default -> 0;
                };
            }

            public void method_17391(int i, int j) {
                switch (i) {
                    case 0 -> OvenBlockEntity.this.litTimeRemaining = j;
                    case 1 -> OvenBlockEntity.this.litTotalTime = j;
                    case 2 -> OvenBlockEntity.this.cookingTimer = j;
                    case 3 -> OvenBlockEntity.this.cookingTotalTime = j;
                }
            }

            public int method_17389() {
                return 4;
            }
        };
        recipesUsed = new Reference2IntOpenHashMap<>();
        quickCheck = class_1863.method_42302(FarmsAndFriendsRecipes.OVEN_TYPE);
    }

    protected class_2561 method_17823() {
        return DEFAULT_NAME;
    }

    protected class_1703 method_5465(int i, class_1661 inventory) {
        return new OvenMenu(i, inventory, this, dataAccess);
    }

    private boolean isLit() {
        return litTimeRemaining > 0;
    }

    protected void method_11014(class_11368 valueInput) {
        super.method_11014(valueInput);
        items = class_2371.method_10213(method_5439(), class_1799.field_8037);
        class_1262.method_5429(valueInput, items);
        cookingTimer = valueInput.method_71432("cooking_time_spent", (short)0);
        cookingTotalTime = valueInput.method_71432("cooking_total_time", (short)0);
        litTimeRemaining = valueInput.method_71432("lit_time_remaining", (short)0);
        litTotalTime = valueInput.method_71432("lit_total_time", (short)0);
        recipesUsed.clear();
        recipesUsed.putAll(valueInput.method_71426("RecipesUsed", RECIPES_USED_CODEC).orElse(Map.of()));
    }

    protected void method_11007(class_11372 valueOutput) {
        super.method_11007(valueOutput);
        valueOutput.method_71471("cooking_time_spent", (short)cookingTimer);
        valueOutput.method_71471("cooking_total_time", (short)cookingTotalTime);
        valueOutput.method_71471("lit_time_remaining", (short)litTimeRemaining);
        valueOutput.method_71471("lit_total_time", (short)litTotalTime);
        class_1262.method_5426(valueOutput, items);
        valueOutput.method_71468("RecipesUsed", RECIPES_USED_CODEC, recipesUsed);
    }

    public static void serverTick(class_3218 serverLevel, class_2338 blockPos, class_2680 blockState, OvenBlockEntity blockEntity) {
        boolean bl = blockEntity.isLit();
        boolean bl2 = false;
        if (blockEntity.isLit()) {
            --blockEntity.litTimeRemaining;
        }

        class_1799 fuelStack = blockEntity.items.get(6);
        class_1799 inputStack = blockEntity.items.get(0);
        boolean bl3 = !inputStack.method_7960();
        boolean bl4 = !fuelStack.method_7960();
        if (blockEntity.isLit() || bl4 && bl3) {
            OvenRecipeInput input = new OvenRecipeInput(blockEntity.items.subList(0, 6));
            class_8786<OvenRecipe> recipeHolder;
            if (bl3) {
                recipeHolder = blockEntity.quickCheck.method_42303(input, serverLevel).orElse(null);
            } else {
                recipeHolder = null;
            }

            int i = blockEntity.method_5444();
            if (!blockEntity.isLit() && canBurn(serverLevel.method_30349(), recipeHolder, input, blockEntity.items, i)) {
                blockEntity.litTimeRemaining = blockEntity.getBurnDuration(serverLevel.method_61269(), fuelStack);
                blockEntity.litTotalTime = blockEntity.litTimeRemaining;
                if (blockEntity.isLit()) {
                    bl2 = true;
                    if (bl4) {
                        class_1792 item = fuelStack.method_7909();
                        fuelStack.method_7934(1);
                        if (fuelStack.method_7960()) {
                            blockEntity.items.set(6, item.method_7858());
                        }
                    }
                }
            }

            if (blockEntity.isLit() && canBurn(serverLevel.method_30349(), recipeHolder, input, blockEntity.items, i)) {
                ++blockEntity.cookingTimer;
                if (blockEntity.cookingTimer == blockEntity.cookingTotalTime) {
                    blockEntity.cookingTimer = 0;
                    blockEntity.cookingTotalTime = getTotalCookTime(serverLevel, blockEntity);
                    if (burn(serverLevel.method_30349(), recipeHolder, input, blockEntity.items, i)) {
                        blockEntity.method_7662(recipeHolder);
                    }

                    bl2 = true;
                }
            } else {
                blockEntity.cookingTimer = 0;
            }
        } else if (!blockEntity.isLit() && blockEntity.cookingTimer > 0) {
            blockEntity.cookingTimer = class_3532.method_15340(blockEntity.cookingTimer - 2, 0, blockEntity.cookingTotalTime);
        }

        if (bl != blockEntity.isLit()) {
            bl2 = true;
            blockState = blockState.method_11657(class_2363.field_11105, blockEntity.isLit());
            serverLevel.method_8652(blockPos, blockState, 3);
        }

        if (bl2) {
            method_31663(serverLevel, blockPos, blockState);
        }
    }

    private static boolean canBurn(class_5455 registryAccess, @Nullable class_8786<OvenRecipe> recipeHolder, OvenRecipeInput input, class_2371<class_1799> list, int i) {
        if (!input.method_59987() && recipeHolder != null) {
            class_1799 result = recipeHolder.comp_1933().assemble(input, registryAccess);
            if (result.method_7960()) {
                return false;
            } else {
                class_1799 output = list.get(7);
                if (output.method_7960()) {
                    return true;
                } else if (!class_1799.method_31577(output, result)) {
                    return false;
                } else if (output.method_7947() < i && output.method_7947() < output.method_7914()) {
                    return true;
                } else {
                    return output.method_7947() < result.method_7914();
                }
            }
        } else return false;
    }

    private static boolean burn(class_5455 registryAccess, @Nullable class_8786<OvenRecipe> recipeHolder, OvenRecipeInput input, class_2371<class_1799> list, int i) {
        if (recipeHolder != null && canBurn(registryAccess, recipeHolder, input, list, i)) {
            class_1799 result = recipeHolder.comp_1933().assemble(input, registryAccess);
            class_1799 output = list.get(7);
            if (output.method_7960()) {
                list.set(7, result.method_7972());
            } else if (class_1799.method_31577(output, result)) {
                output.method_7933(1);
            }

            if (list.subList(0, 6).stream().anyMatch(stack -> stack.method_31574(class_2246.field_10562.method_8389())) && !list.get(6).method_7960() && list.get(6).method_31574(class_1802.field_8550)) {
                list.set(6, new class_1799(class_1802.field_8705));
            }

            for (int j = 0; j < 6; ++j) {
                list.get(j).method_7934(1);
            }
            return true;
        } else {
            return false;
        }
    }

    protected int getBurnDuration(class_9895 fuelValues, class_1799 itemStack) {
        return fuelValues.method_61755(itemStack);
    }

    private static int getTotalCookTime(class_3218 serverLevel, OvenBlockEntity ovenBlockEntity) {
        OvenRecipeInput input = new OvenRecipeInput(ovenBlockEntity.items.subList(0, 6));
        return ovenBlockEntity.quickCheck.method_42303(input, serverLevel).map((recipeHolder) -> recipeHolder.comp_1933().cookingTime()).orElse(200);
    }

    public int[] method_5494(class_2350 direction) {
        if (direction == class_2350.field_11033) {
            return SLOTS_FOR_DOWN;
        } else {
            return direction == class_2350.field_11036 ? SLOTS_FOR_UP : SLOTS_FOR_SIDES;
        }
    }

    public boolean method_5492(int i, class_1799 itemStack, @Nullable class_2350 direction) {
        return method_5437(i, itemStack);
    }

    public boolean method_5493(int i, class_1799 itemStack, class_2350 direction) {
        if (direction == class_2350.field_11033 && i == 6) {
            return itemStack.method_31574(class_1802.field_8705) || itemStack.method_31574(class_1802.field_8550);
        } else {
            return true;
        }
    }

    public int method_5439() {
        return items.size();
    }

    protected class_2371<class_1799> method_11282() {
        return items;
    }

    protected void method_11281(class_2371<class_1799> nonNullList) {
        items = nonNullList;
    }

    public void method_5447(int i, class_1799 itemStack) {
        class_1799 itemStack2 = items.get(i);
        boolean bl = !itemStack.method_7960() && class_1799.method_31577(itemStack2, itemStack);
        items.set(i, itemStack);
        itemStack.method_58408(method_58350(itemStack));
        if (i >= 0 && i < 6 && !bl) {
            if (field_11863 instanceof class_3218 serverLevel) {
                cookingTotalTime = getTotalCookTime(serverLevel, this);
                cookingTimer = 0;
                method_5431();
            }
        }
    }

    public boolean method_5437(int i, class_1799 itemStack) {
        if (i == 7) {
            return false;
        } else if (i < 6 && i >= 0) {
            return true;
        } else {
            class_1799 itemStack2 = items.get(6);
            return field_11863.method_61269().method_61752(itemStack) || itemStack.method_31574(class_1802.field_8550) && !itemStack2.method_31574(class_1802.field_8550);
        }
    }

    public void method_7662(@Nullable class_8786<?> recipeHolder) {
        if (recipeHolder != null) {
            class_5321<class_1860<?>> resourceKey = recipeHolder.comp_1932();
            recipesUsed.addTo(resourceKey, 1);
        }
    }

    public @Nullable class_8786<?> method_7663() {
        return null;
    }

    public void method_7664(class_1657 player, List<class_1799> list) {
    }

    public void awardUsedRecipesAndPopExperience(class_3222 serverPlayer) {
        List<class_8786<?>> list = getRecipesToAwardAndPopExperience(serverPlayer.method_51469(), serverPlayer.method_73189());
        serverPlayer.method_7254(list);

        for(class_8786<?> recipeHolder : list) {
            serverPlayer.method_51283(recipeHolder, items);
        }

        recipesUsed.clear();
    }

    public List<class_8786<?>> getRecipesToAwardAndPopExperience(class_3218 serverLevel, class_243 vec3) {
        List<class_8786<?>> list = Lists.newArrayList();

        for (Reference2IntMap.Entry<class_5321<class_1860<?>>> entry : recipesUsed.reference2IntEntrySet()) {
            serverLevel.method_64577().method_8130(entry.getKey()).ifPresent((recipeHolder) -> {
                list.add(recipeHolder);
                createExperience(serverLevel, vec3, entry.getIntValue(), ((OvenRecipe) recipeHolder.comp_1933()).experience());
            });
        }

        return list;
    }

    private static void createExperience(class_3218 serverLevel, class_243 vec3, int i, float f) {
        int j = class_3532.method_15375((float)i * f);
        float g = class_3532.method_22450((float)i * f);
        if (g != 0f && serverLevel.field_9229.method_43057() < g) {
            ++j;
        }

        class_1303.method_31493(serverLevel, vec3, j);
    }

    public void method_7683(class_9875 stackedItemContents) {
        for(class_1799 itemStack : items) {
            stackedItemContents.method_61541(itemStack);
        }
    }

    public void method_66473(class_2338 blockPos, class_2680 blockState) {
        super.method_66473(blockPos, blockState);
        if (field_11863 instanceof class_3218 serverLevel) {
            getRecipesToAwardAndPopExperience(serverLevel, class_243.method_24953(blockPos));
        }
    }
}
