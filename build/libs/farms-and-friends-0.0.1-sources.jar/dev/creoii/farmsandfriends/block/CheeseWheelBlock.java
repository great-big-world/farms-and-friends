package dev.creoii.farmsandfriends.block;

import com.mojang.serialization.MapCodec;
import dev.creoii.farmsandfriends.registry.FarmsAndFriendsStats;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2272;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;

public class CheeseWheelBlock extends class_2248 {
    public static final MapCodec<class_2272> CODEC = method_54094(class_2272::new);
    public static final class_2758 BITES = class_2758.method_11867("bites", 0, 3);
    private static final class_265 ONE_BITE_SHAPE = class_259.method_1084(class_2248.method_9541(1d, 0d, 1d, 8d, 6d, 15d), class_2248.method_9541(8d, 0d, 1d, 15d, 6d, 8d));
    private static final class_265 TWO_BITES_SHAPE = class_2248.method_9541(1d, 0d, 1d, 8d, 6d, 15d);
    private static final class_265 THREE_BITES_SHAPE = class_2248.method_9541(1d, 0d, 1d, 8d, 6d, 8d);
    private static final class_265[] SHAPES = new class_265[]{class_2248.method_9541(1d, 0d, 1d, 15d, 6d, 15d), ONE_BITE_SHAPE, TWO_BITES_SHAPE, THREE_BITES_SHAPE};
    public static final int FULL_CAKE_SIGNAL = getOutputSignal(0);
    private final boolean moldy;

    public MapCodec<class_2272> method_53969() {
        return field_46280;
    }

    public CheeseWheelBlock(class_4970.class_2251 properties, boolean moldy) {
        super(properties);
        method_9590(field_10647.method_11664().method_11657(BITES, 0));
        this.moldy = moldy;
    }

    public boolean isMoldy() {
        return moldy;
    }

    protected class_265 method_9530(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext) {
        return SHAPES[blockState.method_11654(BITES)];
    }

    protected class_1269 method_55766(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, class_3965 blockHitResult) {
        if (level.method_8608()) {
            if (eat(level, blockPos, blockState, player).method_23665()) {
                return class_1269.field_5812;
            }

            if (player.method_5998(class_1268.field_5808).method_7960()) {
                return class_1269.field_21466;
            }
        }

        return eat(level, blockPos, blockState, player);
    }

    protected static class_1269 eat(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_1657 player) {
        if (!player.method_7332(false)) {
            return class_1269.field_5811;
        } else {
            player.method_7281(FarmsAndFriendsStats.EAT_CHEESE_BITE);
            player.method_7344().method_7585(2, 0.1f);
            int i = blockState.method_11654(BITES);
            levelAccessor.method_33596(player, class_5712.field_28735, blockPos);
            if (i < 3) {
                levelAccessor.method_8652(blockPos, blockState.method_11657(BITES, i + 1), 3);
            } else {
                levelAccessor.method_8650(blockPos, false);
                levelAccessor.method_33596(player, class_5712.field_28165, blockPos);
            }

            return class_1269.field_5812;
        }
    }

    protected class_2680 method_9559(class_2680 blockState, class_4538 levelReader, class_10225 scheduledTickAccess, class_2338 blockPos, class_2350 direction, class_2338 blockPos2, class_2680 blockState2, class_5819 randomSource) {
        return direction == class_2350.field_11033 && !blockState.method_26184(levelReader, blockPos) ? class_2246.field_10124.method_9564() : super.method_9559(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
    }

    protected boolean method_9558(class_2680 blockState, class_4538 levelReader, class_2338 blockPos) {
        return levelReader.method_8320(blockPos.method_10074()).method_51367();
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(BITES);
    }

    protected int method_9572(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2350 direction) {
        return getOutputSignal(blockState.method_11654(BITES));
    }

    public static int getOutputSignal(int i) {
        return (5 - i) * 3;
    }

    protected boolean method_9498(class_2680 blockState) {
        return true;
    }

    protected boolean method_9516(class_2680 blockState, class_10 pathComputationType) {
        return false;
    }
}
