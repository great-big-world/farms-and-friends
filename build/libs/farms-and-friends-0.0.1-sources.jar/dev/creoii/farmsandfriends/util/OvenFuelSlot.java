package dev.creoii.farmsandfriends.util;

import dev.creoii.farmsandfriends.menu.OvenMenu;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class OvenFuelSlot extends class_1735 {
    private final OvenMenu menu;

    public OvenFuelSlot(OvenMenu menu, class_1263 container, int i, int j, int k) {
        super(container, i, j, k);
        this.menu = menu;
    }

    public boolean method_7680(class_1799 itemStack) {
        return menu.isFuel(itemStack) || isBucket(itemStack);
    }

    public int method_7676(class_1799 itemStack) {
        return isBucket(itemStack) ? 1 : super.method_7676(itemStack);
    }

    public static boolean isBucket(class_1799 itemStack) {
        return itemStack.method_31574(class_1802.field_8550);
    }
}
