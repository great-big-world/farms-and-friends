package dev.creoii.farmsandfriends.util;

import net.minecraft.class_10331;

public final class FarmsAndFriendsSearchRecipeBookCategories {
    public static class_10331 OVEN = class_10331.valueOf("GBW_OVEN");
}
