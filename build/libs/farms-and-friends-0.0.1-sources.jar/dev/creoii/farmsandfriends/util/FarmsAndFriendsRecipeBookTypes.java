package dev.creoii.farmsandfriends.util;

import net.minecraft.class_5421;

public final class FarmsAndFriendsRecipeBookTypes {
    public static final class_5421 OVEN = class_5421.valueOf("GBW_OVEN");
}
